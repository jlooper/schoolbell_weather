schoolbell_weather
==================

App created using Kendo UI Mobile. This is a cross-platform hybrid mobile app that will show kids what the weather will be like when they need to go to school.
